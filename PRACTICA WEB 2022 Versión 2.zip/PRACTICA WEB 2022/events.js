window.onload = function () {
    var boton = document.getElementById('button');
    var testD = document.getElementById('title');

    testD.addEventListener('mouseover', function(){
    console.log("hmm kinky bastard!! hehee")
})

    boton.addEventListener('click', function(){
        window.alert("YOU ARE GREAT AND VALID NO MATTER YOUR TASTES")
        console.log("button push")
    })

}

